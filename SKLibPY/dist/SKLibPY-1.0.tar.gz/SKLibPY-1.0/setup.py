from setuptools import setup

setup(
    name='SKLibPY',
    version='1.0',
    packages=['SKLibPY', 'SKLibPY.WebLogic', 'SKLibPY.FileSystem', 'SKLibPY.Communication'],
    url='',
    license='Owned by Shashikant',
    author='Shashikant Kumar',
    author_email='shkumar@live.in',
    description='Utility Library'
)
